import Navbar from "./components/Navbar";
import { Outlet } from "react-router-dom";
import Footer from "./components/Footer";
function MainLayout(){
    return (
        <>
     
        <div className="">
        <Navbar/>
        </div>
        <div className="">
        <Outlet/>
        </div>
        <div className="sm:max-h-svh">
        <Footer /> 
        </div>
        
       
      
        
        </>
    )
}
export default MainLayout;